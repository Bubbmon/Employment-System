#!/bin/bash
nohup mvn spring-boot:run > log.out 2>&1 &