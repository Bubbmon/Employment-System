package com.system.entity;

/**
 * @Author Legion
 * @Date 2021/6/12 17:05
 * @Description 求职者和hr会实现的一个接口，为了减少重复代码所以用的，想用就用
 */
public interface Customer {
    String getPswd();
    String getId();
}
