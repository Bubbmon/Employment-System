package com.system.entity;

import lombok.Data;

/**
 * @Author Legion
 * @Date 2021/6/12 15:28
 * @Description
 */
@Data
public class Info {
    private long id;
    private String title;
    private String content;
}
